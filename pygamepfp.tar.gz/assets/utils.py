# utility functions for the racing project

def clamp(val, min_val, max_val):
    return max(min_val, min(max_val, val))
