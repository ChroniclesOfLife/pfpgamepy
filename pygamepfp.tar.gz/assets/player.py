import pygame
import math

class HumanCar:
    def __init__(self, x, y, color=(255,0,0), controls="wasd"):
        self.x = x
        self.y = y
        self.angle = 0
        self.color = color
        self.width = 40
        self.height = 20
        self.speed = 0.0 # current speed
        self.acceleration = 200.0 # pixels/sec^2
        self.deceleration = 400.0 # pixels/sec^2
        self.max_speed = 200.0 # pixels/sec
        self.turn_speed = 150.0 # degrees/sec
        self.controls = controls
        self.car_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        self.car_surface.fill(self.color)

    def update(self, dt):
        pressed = pygame.key.get_pressed()
        
        # Acceleration/Deceleration
        if (self.controls == "wasd" and pressed[pygame.K_w]) or \
           (self.controls == "arrows" and pressed[pygame.K_UP]):
            self.speed += self.acceleration * dt
        elif (self.controls == "wasd" and pressed[pygame.K_s]) or \
             (self.controls == "arrows" and pressed[pygame.K_DOWN]):
            self.speed -= self.deceleration * dt # Decelerate faster than accelerate
        else:
            # Gradual stop if no keys pressed
            if self.speed > 0:
                self.speed -= self.deceleration * dt
                if self.speed < 0: self.speed = 0
            elif self.speed < 0:
                self.speed += self.deceleration * dt
                if self.speed > 0: self.speed = 0

        self.speed = max(-self.max_speed / 2, min(self.speed, self.max_speed))

        # Turning
        if (self.controls == "wasd" and pressed[pygame.K_a]) or \
           (self.controls == "arrows" and pressed[pygame.K_LEFT]):
            self.angle += self.turn_speed * dt
        if (self.controls == "wasd" and pressed[pygame.K_d]) or \
           (self.controls == "arrows" and pressed[pygame.K_RIGHT]):
            self.angle -= self.turn_speed * dt

        # Movement
        rad = math.radians(self.angle)
        self.x += self.speed * math.cos(rad) * dt
        self.y -= self.speed * math.sin(rad) * dt # Y is inverted in Pygame

    def draw(self, surface):
        rotated = pygame.transform.rotozoom(self.car_surface, self.angle, 1) # 1 is scale
        rect = rotated.get_rect(center=(self.x, self.y))
        surface.blit(rotated, rect.topleft)

