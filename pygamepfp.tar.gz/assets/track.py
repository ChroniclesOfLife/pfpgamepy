import pygame

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

class Track:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.surface = pygame.Surface((width, height))
        self.draw_track()

    def draw_track(self):
        self.surface.fill(WHITE)
        # this replicates the rectangular loop used in the simulator
        # Use pygame.draw.aaline or draw thicker lines and then smooth if needed
        pygame.draw.rect(self.surface, BLACK, (100, 100, 600, 400), width=30)

    def get_pixel_color(self, x, y):
        if 0 <= x < self.width and 0 <= y < self.height:
            return self.surface.get_at((x, y))
        return WHITE
