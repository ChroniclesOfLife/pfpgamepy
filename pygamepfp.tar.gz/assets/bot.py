import math
import pygame

try:
    # try importing the shared logic from the sibling project
    from pi5servo360PiAiCamera2Lines.robot_logic import RobotLogic
except ImportError:
    # if not installed editable, fall back to a simple placeholder
    class RobotLogic:
        def __init__(self, kp=0.5, kd=0.1):
            self.kp = kp
            self.kd = kd
            self.prev_error = 0
        def calculate_pid(self, error):
            if error is None:
                return 0, "", 0, 0
            derivative = error - self.prev_error
            output = self.kp * error + self.kd * derivative
            self.prev_error = error
            return output, "", 0, 0

from track import Track

class BotCar:
    def __init__(self, x, y, color=(0,255,0), logic=None):
        self.x = x
        self.y = y
        self.angle = 0
        self.width = 40
        self.height = 20
        self.base_speed = 150.0 # pixels/sec
        self.turn_speed = 100.0 # degrees/sec based on PID output
        self.color = color
        self.logic = logic or RobotLogic()
        self.sensor_dist = 25
        self.sensor_spread = 20
        self.car_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        self.car_surface.fill(self.color)

    def move(self, pid_output, dt):
        # simple tank steering like original simulator
        turn_adjust = max(-1.0, min(1.0, pid_output)) # Normalize PID output for turning
        self.angle -= turn_adjust * self.turn_speed * dt
        rad = math.radians(self.angle)
        self.x += self.base_speed * math.cos(rad) * dt
        self.y -= self.base_speed * math.sin(rad) * dt # Y is inverted in Pygame

    def get_camera_error(self, track_surface):
        scan_width = 160
        rad = math.radians(self.angle)
        cx = self.x + self.sensor_dist * math.cos(rad)
        cy = self.y - self.sensor_dist * math.sin(rad)
        perp_rad = rad - math.pi/2
        dx = math.cos(perp_rad)
        dy = -math.sin(perp_rad)
        black_pixels = []
        for i in range(int(-scan_width/2), int(scan_width/2)):
            px = int(cx + i * dx)
            py = int(cy + i * dy)
            if 0 <= px < track_surface.get_width() and 0 <= py < track_surface.get_height(): # Use track_surface dimensions
                color = track_surface.get_at((px, py))
            else:
                color = (255,255,255)
            if color[0] < 100: # Assuming black line
                black_pixels.append(i)
        error = None
        if black_pixels:
            error = sum(black_pixels) / len(black_pixels)
        return error

    def update(self, dt, track_surface):
        error = self.get_camera_error(track_surface)
        pid_output, _, _, _ = self.logic.calculate_pid(error)
        self.move(pid_output, dt)

    def draw(self, surface):
        rotated = pygame.transform.rotozoom(self.car_surface, self.angle, 1) # 1 is scale
        rect = rotated.get_rect(center=(self.x, self.y))
        surface.blit(rotated, rect.topleft)
