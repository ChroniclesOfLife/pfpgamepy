import asyncio
import pygame
import random
import math
import sys

# --- GLOBAL CONFIG ---
WIDTH, HEIGHT = 1280, 720
BLACK = (5, 5, 8)
NEON_CYAN = (0, 255, 255)
NEON_PINK = (255, 20, 147)
NEON_GREEN = (57, 255, 20)
NEON_YELLOW = (255, 255, 0)
NEON_RED = (255, 20, 57)
GOLD = (255, 215, 0)
WHITE = (255, 255, 255)
DARK_GRAY = (30, 30, 35)
LIGHT_GRAY = (150, 150, 150)

# --- ASSET GENERATION (Advanced Procedural Graphics) ---

def create_crt_overlay(width, height):
    """Creates a surface with scanlines and a vignette effect."""
    overlay = pygame.Surface((width, height), pygame.SRCALPHA)
    # Vignette
    for y in range(height):
        for x in range(0, width, 4): # Optimization: step by 4
            dist_x = (x - width/2) / (width/2)
            dist_y = (y - height/2) / (height/2)
            dist = math.sqrt(dist_x**2 + dist_y**2)
            alpha = min(255, int(max(0, dist - 0.5) * 200)) # Darken edges
            if alpha > 0:
                pygame.draw.rect(overlay, (0, 0, 0, alpha), (x, y, 4, 1))

    # Scanlines
    for y in range(0, height, 3):
        pygame.draw.line(overlay, (0, 0, 0, 80), (0, y), (width, y))
    return overlay

CRT_OVERLAY = None # Initialized in main()

def draw_3d_grid(surface, color, offset_y, time_ticks):
    """Draws a moving 3D synthwave grid."""
    center_x, center_y = WIDTH//2, HEIGHT//2 - 50
    horizon = HEIGHT//2 - 100
    
    # Horizontal lines moving towards viewer
    speed = 2
    offset = (time_ticks * speed) % 50
    for i in range(15):
        y = horizon + (i * 50) + offset
        if y > HEIGHT + 100: continue
        # Calculate thickness based on distance
        thickness = max(1, int((y - horizon) / 80))
        y_pos = min(HEIGHT, int(y + offset_y))
        pygame.draw.line(surface, color, (0, y_pos), (WIDTH, y_pos), thickness)

    # Perspective vertical lines
    num_lines = 20
    for i in range(-num_lines, num_lines):
        x_bottom = center_x + (i * 120)
        pygame.draw.line(surface, color, (center_x, horizon + offset_y), (x_bottom, HEIGHT + offset_y), max(1, int(abs(i)/4)))

def draw_neon_rect(surface, color, rect, width=4, glow=True):
    pygame.draw.rect(surface, color, rect, width)
    if glow:
        for i in range(1, 4): # Reduced for performance with other FX
            alpha = max(0, 100 - i * 30)
            glow_surf = pygame.Surface((rect.width + i*8, rect.height + i*8), pygame.SRCALPHA)
            pygame.draw.rect(glow_surf, (*color, alpha), glow_surf.get_rect(), width=max(1, int(width/2)))
            surface.blit(glow_surf, (rect.x - i*4, rect.y - i*4))

def create_car_surface(color, size=(40, 40), headlights=True):
    surf = pygame.Surface(size, pygame.SRCALPHA)
    pygame.draw.rect(surf, color, surf.get_rect())
    if headlights:
        pygame.draw.ellipse(surf, WHITE, (5, 5, 8, 8))
        pygame.draw.ellipse(surf, WHITE, (size[0]-13, 5, 8, 8))
        # Headlight beams (simple triangles)
        beam_surf = pygame.Surface((30, 40), pygame.SRCALPHA)
        pygame.draw.polygon(beam_surf, (255, 255, 255, 40), [(15, 0), (0, 40), (30, 40)])
        surf.blit(beam_surf, (size[0]//2 - 15, -35))
    return surf

def draw_text_centered(surface, text, font, color, y, x_offset=0):
    txt_surf = font.render(text, True, color)
    surface.blit(txt_surf, (WIDTH//2 - txt_surf.get_width()//2 + x_offset, y))
    return txt_surf.get_rect(center=(WIDTH//2 + x_offset, y + txt_surf.get_height()//2))

# --- CLASSES ---
class Particle:
    def __init__(self, x, y, color, life=30, speed=2, size=4, shape="circle"):
        self.x = x
        self.y = y
        self.color = color
        self.life = float(life)
        self.max_life = float(life)
        self.size = size
        self.shape = shape
        angle = random.uniform(0, 2 * math.pi)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 1
        
    def draw(self, surface):
        if self.life > 0:
            alpha = int((self.life / self.max_life) * 255)
            s = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
            if self.shape == "circle":
                pygame.draw.circle(s, (*self.color[:3], alpha), (self.size//2, self.size//2), self.size//2)
            else:
                pygame.draw.rect(s, (*self.color[:3], alpha), s.get_rect())
            surface.blit(s, (int(self.x), int(self.y)))

class Player(pygame.sprite.Sprite):
    def __init__(self, name, x, y, color, controls, track_rects):
        super().__init__()
        self.name = name
        self.original_color = color
        self.color = color
        self.size = (40, 40)
        self.image = create_car_surface(self.color, self.size)
        self.rect = self.image.get_rect(center=(x, y))
        self.controls = controls
        self.track_outer, self.track_inner = track_rects
        
        self.base_speed = 6.0
        self.speed_mult = 1.0
        self.score = 0
        
        self.buff_timer = 0
        self.debuff_active = None
        self.debuff_timer = 0
        
        self.god_mode = False
        self.is_chicken = False
        self.immune = False
        self.input_lag = False
        self.input_queue = []
        self.particles = []
        self.god_hue = 0
        self.screen_shake_frames = 0
        
        self._apply_easter_eggs()
        
    def _apply_easter_eggs(self):
        n = self.name.lower()
        if n == "wibu":
            self.god_mode = True
            self.base_speed = 12.0
        elif n == "vu":
            self.immune = True
            self.color = (100, 100, 255) # Tank
        elif n == "domixi":
            self.base_speed = 10.2 # +70%
        elif n == "thread":
            self.input_lag = True
            self.base_speed = 5.0
        self.image = create_car_surface(self.color, self.size)
            
    def apply_buff(self, buff_type, game):
        # Massive explosion
        for _ in range(50): self.particles.append(Particle(self.rect.centerx, self.rect.centery, GOLD, 40, random.uniform(2, 6), 6, "rect"))
        self.screen_shake_frames = 10

        if buff_type == "Tayf Roiwf":
            self.speed_mult = 1.5
            self.buff_timer = 300
            game.add_popup(self, "Tayf Roiwf! (+50% Speed / Trail)", NEON_CYAN)
        elif buff_type == "Li Xi Mixi":
            self.score += 1000
            self.buff_timer = 300
            game.add_popup(self, "Lì Xì Mixi! (+1000 Score / Shield)", GOLD)
        elif buff_type == "Kho Ga De Tem Ngon Thi":
            self.is_chicken = True
            self.buff_timer = 400
            self.color = GOLD
            self.image = create_car_surface(self.color, self.size)
            game.add_popup(self, "Khô Gà Mode! (Invincible + Knockback)", GOLD)

    def apply_debuff(self, debuff_type, game):
        for _ in range(30): self.particles.append(Particle(self.rect.centerx, self.rect.centery, NEON_RED, 30, random.uniform(2, 5), 4))
        self.screen_shake_frames = 20

        if self.immune or self.god_mode or self.is_chicken or self.buff_timer > 0:
            game.add_popup(self, "BLOCKED!", LIGHT_GRAY)
            return
            
        self.debuff_active = debuff_type
        if debuff_type == "Alo Vũ à em":
            self.debuff_timer = 120 # 2s freeze
            game.add_popup(self, "Alo Vũ à em? (-100% Speed 2s)", NEON_RED)
        elif debuff_type == "1 Chạy Tự Ta":
            self.debuff_timer = 300
            game.add_popup(self, "1 Chạy Tự Ta! (-90% Speed 5s)", NEON_RED)
        elif debuff_type == "Chưa Tay Đâu":
            self.debuff_timer = 300
            game.add_popup(self, "Chưa Tay Đâu! (Inverted Ctrl + Chromatic Aberration)", NEON_PINK)

    def update(self, keys, events, game):
        if self.screen_shake_frames > 0:
            self.screen_shake_frames -= 1

        if self.buff_timer > 0:
            self.buff_timer -= 1
            if self.buff_timer <= 0:
                self.speed_mult = 1.0
                self.is_chicken = False
                self.color = self.original_color
                self.image = create_car_surface(self.color, self.size)
                
        if self.debuff_timer > 0:
            self.debuff_timer -= 1
            if self.debuff_timer <= 0:
                self.debuff_active = None
                
        # God mode visuals
        if self.god_mode:
            self.god_hue = (self.god_hue + 10) % 360
            color = pygame.Color(0)
            color.hsva = (self.god_hue, 100, 100, 100)
            self.color = (color.r, color.g, color.b)
            self.image = create_car_surface(self.color, self.size)
            if random.random() < 0.7:
                self.particles.append(Particle(self.rect.centerx, self.rect.centery, self.color, 40, 3, 6))

        # Particles for buffs
        if self.speed_mult > 1.0 and not self.god_mode:
            if random.random() < 0.4:
                 self.particles.append(Particle(self.rect.centerx, self.rect.centery, NEON_CYAN, 20, 1))
        if "domixi" in self.name.lower() and random.random() < 0.2:
             # Golden Money particles
             self.particles.append(Particle(self.rect.centerx, self.rect.centery, GOLD, 30, 2, 5, "rect"))

        for p in self.particles[:]:
            p.update()
            if p.life <= 0: self.particles.remove(p)

        speed = self.base_speed * self.speed_mult
        
        if self.debuff_active == "Alo Vũ à em": return # Frozen
        if self.debuff_active == "1 Chạy Tự Ta": speed *= 0.1
        if self.god_mode: speed = 15.0

        dx, dy = 0, 0
        up, down, left, right = self.controls
        
        if self.input_lag:
            self.input_queue.append((keys[up], keys[down], keys[left], keys[right]))
            if len(self.input_queue) > 30:
                k_up, k_down, k_left, k_right = self.input_queue.pop(0)
            else:
                k_up, k_down, k_left, k_right = False, False, False, False
        else:
            k_up, k_down, k_left, k_right = keys[up], keys[down], keys[left], keys[right]

        if self.debuff_active == "Chưa Tay Đâu":
            k_up, k_down, k_left, k_right = k_down, k_up, k_right, k_left
            if random.random() < 0.2: # Jitter
                dx += random.randint(-8, 8)
                dy += random.randint(-8, 8)

        if k_up: dy -= speed
        if k_down: dy += speed
        if k_left: dx -= speed
        if k_right: dx += speed
        
        if game.wind_active: dx += 4.0

        self.rect.x += dx
        self.rect.y += dy

        if not self.god_mode:
            self.rect.clamp_ip(self.track_outer)
            if self.rect.colliderect(self.track_inner):
                ox = min(abs(self.rect.right - self.track_inner.left), abs(self.rect.left - self.track_inner.right))
                oy = min(abs(self.rect.bottom - self.track_inner.top), abs(self.rect.top - self.track_inner.bottom))
                if ox < oy:
                    if self.rect.centerx < self.track_inner.centerx: self.rect.right = self.track_inner.left
                    else: self.rect.left = self.track_inner.right
                else:
                    if self.rect.centery < self.track_inner.centery: self.rect.bottom = self.track_inner.top
                    else: self.rect.top = self.track_inner.bottom

class Bot(pygame.sprite.Sprite):
    def __init__(self, mode, track_rects):
        super().__init__()
        self.mode = mode
        self.image = pygame.Surface((30, 30))
        self.image.fill(NEON_GREEN)
        pygame.draw.rect(self.image, WHITE, self.image.get_rect(), 3)
        self.rect = self.image.get_rect(center=(150, 150))
        self.track_outer, self.track_inner = track_rects
        self.speed = 4.0 if mode == "NOOB" else 6.5
        self.vel = [self.speed, 0]
        self.glitch_timer = 0
        
    def update(self, players):
        if self.mode == "NOOB":
            self.rect.x += self.vel[0]
            self.rect.y += self.vel[1]
            if self.vel[0] > 0 and self.rect.right >= self.track_outer.right - 20: self.vel = [0, self.speed]
            elif self.vel[1] > 0 and self.rect.bottom >= self.track_outer.bottom - 20: self.vel = [-self.speed, 0]
            elif self.vel[0] < 0 and self.rect.left <= self.track_outer.left + 20: self.vel = [0, -self.speed]
            elif self.vel[1] < 0 and self.rect.top <= self.track_outer.top + 20: self.vel = [self.speed, 0]
                
        elif self.mode == "PRO":
            self.speed = min(13.0, self.speed + 0.003) # Accelerates faster
            if players:
                closest = min(players, key=lambda p: math.hypot(p.rect.x - self.rect.x, p.rect.y - self.rect.y))
                dx = closest.rect.x - self.rect.x
                dy = closest.rect.y - self.rect.y
                dist = math.hypot(dx, dy)
                if dist > 0:
                    self.vel = [(dx/dist) * self.speed, (dy/dist) * self.speed]
                self.rect.x += self.vel[0]
                self.rect.y += self.vel[1]
            self.rect.clamp_ip(self.track_outer)
            if self.rect.colliderect(self.track_inner):
                if self.rect.centerx < self.track_inner.centerx: self.rect.right = self.track_inner.left
                elif self.rect.centerx > self.track_inner.centerx: self.rect.left = self.track_inner.right
                if self.rect.centery < self.track_inner.centery: self.rect.bottom = self.track_inner.top
                elif self.rect.centery > self.track_inner.centery: self.rect.top = self.track_inner.bottom
                
        elif self.mode == "HACKER":
            self.glitch_timer += 1
            if random.random() < 0.08 or self.glitch_timer > 60:
                self.glitch_timer = 0
                for _ in range(15):
                    nx = random.randint(self.track_outer.x, self.track_outer.right - 30)
                    ny = random.randint(self.track_outer.y, self.track_outer.bottom - 30)
                    if not pygame.Rect(nx, ny, 30, 30).colliderect(self.track_inner):
                        self.rect.topleft = (nx, ny)
                        break

class PopupText:
    def __init__(self, x, y, text, color=WHITE):
        self.x = x
        self.y = y
        self.text = text
        self.color = color
        self.life = 100
        self.scale = 0.5
    def update(self):
        self.y -= 1.5
        self.life -= 1
        if self.scale < 1.0: self.scale += 0.05

# --- GAME LOGIC ---
class Game:
    def __init__(self):
        self.state = "LOBBY"
        self.p1_name = "Player1"
        self.num_players = 2
        self.timer_limit = 60
        self.bot_mode = "HACKER"
        
        self.players = []
        self.bot = None
        self.popups = []
        
        self.track_outer = pygame.Rect(50, 50, WIDTH-100, HEIGHT-100)
        self.track_inner = pygame.Rect(250, 200, WIDTH-500, HEIGHT-400)
        
        self.start_ticks = 0
        self.time_left = 0
        self.event_timer = 0
        self.wind_active = False
        self.blackout = False
        
        # Performance/Web Safe Fonts
        pygame.font.init()
        self.font = pygame.font.SysFont("Arial", 28, bold=True)
        self.large_font = pygame.font.SysFont("Arial", 54, bold=True)
        self.small_font = pygame.font.SysFont("Arial", 20)
        self.title_font = pygame.font.SysFont("Impact", 80)
        self.popup_font = pygame.font.SysFont("Impact", 36)
        
        self.is_paused = False

    def start_game(self):
        self.state = "RACING"
        self.start_ticks = pygame.time.get_ticks()
        self.players = []
        p1 = Player(self.p1_name, 150, HEIGHT//2, NEON_CYAN, (pygame.K_w, pygame.K_s, pygame.K_a, pygame.K_d), (self.track_outer, self.track_inner))
        self.players.append(p1)
        if self.num_players == 2:
            p2 = Player("Player2", int(WIDTH-150), HEIGHT//2, NEON_PINK, (pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT), (self.track_outer, self.track_inner))
            self.players.append(p2)
            
        self.bot = Bot(self.bot_mode, (self.track_outer, self.track_inner))
        self.is_paused = False
        self.popups = []

    def apply_gamble(self, player):
        if random.random() > 0.5:
            outcome = random.choice(["Tayf Roiwf", "Li Xi Mixi", "Kho Ga De Tem Ngon Thi"])
            player.apply_buff(outcome, self)
        else:
            outcome = random.choice(["Alo Vũ à em", "1 Chạy Tự Ta", "Chưa Tay Đâu"])
            player.apply_debuff(outcome, self)

    def add_popup(self, player, text, color):
        self.popups.append(PopupText(player.rect.centerx, player.rect.top - 20, text, color))

class Button:
    def __init__(self, x, y, w, h, text, color, hover_color, font):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.font = font
    def draw(self, surface, mouse_pos):
        color = self.hover_color if self.rect.collidepoint(mouse_pos) else self.color
        pygame.draw.rect(surface, color, self.rect, border_radius=12)
        pygame.draw.rect(surface, WHITE, self.rect, 3, border_radius=12)
        txt = self.font.render(self.text, True, WHITE)
        surface.blit(txt, (self.rect.centerx - txt.get_width()//2, self.rect.centery - txt.get_height()//2))
    def is_clicked(self, mouse_pos, click):
        return self.rect.collidepoint(mouse_pos) and click

async def main():
    global CRT_OVERLAY
    pygame.init()
    # Required for alpha blending & chromatic aberration tricks in software
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Nested Nitro: Meme Racer - Ultimate Graphics")
    clock = pygame.time.Clock()
    game = Game()
    
    # Generate CRT Overlay once
    CRT_OVERLAY = create_crt_overlay(WIDTH, HEIGHT)
    
    # GUI Buttons
    btn_start = Button(WIDTH//2 - 125, 550, 250, 70, "START RACE 🏁", NEON_GREEN, (100,255,100), game.large_font)
    btn_help = Button(WIDTH - 80, 20, 60, 60, "❓", DARK_GRAY, LIGHT_GRAY, game.large_font)
    btn_close_help = Button(WIDTH//2 - 75, HEIGHT - 100, 150, 50, "CLOSE", NEON_RED, (255,100,100), game.font)
    
    name_btns = [
        Button(WIDTH//2 - 420, 300, 180, 50, "Normal Mode", DARK_GRAY, LIGHT_GRAY, game.font),
        Button(WIDTH//2 - 220, 300, 180, 50, "DoMixi", DARK_GRAY, LIGHT_GRAY, game.font),
        Button(WIDTH//2 - 20, 300, 180, 50, "Vu", DARK_GRAY, LIGHT_GRAY, game.font),
        Button(WIDTH//2 + 180, 300, 180, 50, "Wibu", DARK_GRAY, LIGHT_GRAY, game.font),
        Button(WIDTH//2 + 380, 300, 180, 50, "Thread", DARK_GRAY, LIGHT_GRAY, game.font)
    ]
    
    ticks = 0
    running = True
    while running:
        dt = clock.tick(60)
        ticks += 1
        mouse_pos = pygame.mouse.get_pos()
        click = False
        events = pygame.event.get()
        keys = pygame.key.get_pressed()
        
        for event in events:
            if event.type == pygame.QUIT: running = False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1: click = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q: game.state = "LOBBY"
                if event.key == pygame.K_p and game.state == "RACING": game.is_paused = not game.is_paused
                if event.key == pygame.K_g and game.state == "RACING":
                    for p in game.players:
                        p.god_mode = not p.god_mode
                        if p.god_mode: game.add_popup(p, "GLOBAL GOD MODE!", GOLD)
        
        # --- LOBBY SCREEN ---
        if game.state == "LOBBY":
            screen.fill((10, 10, 15))
            draw_3d_grid(screen, (0, 150, 150), 0, ticks)
            
            draw_text_centered(screen, "NESTED NITRO", game.title_font, NEON_CYAN, 80)
            draw_text_centered(screen, "MEME RACER - ULTIMATE EDITION", game.large_font, NEON_PINK, 170)
            
            draw_text_centered(screen, "Select Player 1 Name (Easter Eggs):", game.font, WHITE, 250)
            for i, btn in enumerate(name_btns):
                btn.color = (0, 200, 200) if (game.p1_name == btn.text or (game.p1_name == "Player1" and i==0)) else DARK_GRAY
                btn.draw(screen, mouse_pos)
                if btn.is_clicked(mouse_pos, click): game.p1_name = "Player1" if i == 0 else btn.text
            
            desc = ""
            if game.p1_name == "DoMixi": desc = "Effect: Người Đau Thương Khổ Ga (+70% Speed, Money Trail)"
            elif game.p1_name == "Vu": desc = "Effect: Đồ Danh Dự (Tank, Immune to Debuffs)"
            elif game.p1_name == "Wibu": desc = "Effect: Chạm Cỏ Đi Em (Permanent Rainbow God Mode)"
            elif game.p1_name == "Thread": desc = "Effect: Dân Trí ⬇️ (Hard Mode: Lag, Slow)"
            else: desc = "Standard Racing Mode"
            draw_text_centered(screen, desc, game.font, NEON_YELLOW, 380)
            
            draw_text_centered(screen, f"Players: {game.num_players} (Press 2)", game.font, WHITE, 450)
            draw_text_centered(screen, f"Bot AI: {game.bot_mode} (Press B)", game.font, WHITE, 490)
            
            for event in events:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_2: game.num_players = 1 if game.num_players == 2 else 2
                    if event.key == pygame.K_b:
                        modes = ["NOOB", "PRO", "HACKER"]
                        game.bot_mode = modes[(modes.index(game.bot_mode) + 1) % 3]
            
            btn_start.draw(screen, mouse_pos)
            btn_help.draw(screen, mouse_pos)
            
            if btn_start.is_clicked(mouse_pos, click): game.start_game()
            if btn_help.is_clicked(mouse_pos, click): game.state = "HELP"
            
            # Draw CRT over Lobby
            screen.blit(CRT_OVERLAY, (0,0))
        
        # --- HELP/RULES SCREEN ---
        elif game.state == "HELP":
            screen.fill((15, 10, 20))
            draw_text_centered(screen, "GAMBLE DICTIONARY", game.large_font, GOLD, 50)
            
            y = 150
            draw_text_centered(screen, "--- 🟢 BUFFS (50%) ---", game.font, NEON_GREEN, y); y += 40
            draw_text_centered(screen, "Tayf Roiwf: +50% Speed Burst & Trails for 5s", game.small_font, WHITE, y); y += 30
            draw_text_centered(screen, "Lì Xì Mixi: Instant +1000 Score & Shield", game.small_font, WHITE, y); y += 30
            draw_text_centered(screen, "Khô Gà Mode: Turn Gold, Invincible", game.small_font, WHITE, y); y += 60
            
            draw_text_centered(screen, "--- 🔴 DEBUFFS (50%) ---", game.font, NEON_RED, y); y += 40
            draw_text_centered(screen, "Alo Vũ à em?: Stop answering the phone! (-100% Speed for 2s)", game.small_font, WHITE, y); y += 30
            draw_text_centered(screen, "1 Chạy Tự Ta: Turtle crawl (-90% Speed for 5s)", game.small_font, WHITE, y); y += 30
            draw_text_centered(screen, "Chưa Tay Đâu: Brain rot (Inverted Controls & Visual Glitches for 5s)", game.small_font, WHITE, y); y += 60
            
            btn_close_help.draw(screen, mouse_pos)
            if btn_close_help.is_clicked(mouse_pos, click) or (events and any(e.type == pygame.KEYDOWN for e in events)): game.state = "LOBBY"
            screen.blit(CRT_OVERLAY, (0,0))

        # --- RACING SCREEN ---
        elif game.state == "RACING":
            if not game.is_paused:
                elapsed = (pygame.time.get_ticks() - game.start_ticks) // 1000
                game.time_left = max(0, game.timer_limit - elapsed)
                if game.time_left <= 0: game.state = "SUMMARY"
                
                game.event_timer += dt
                if game.event_timer > 20000:
                    game.event_timer = 0
                    event_type = random.choice(["RESET", "WIND", "BLACKOUT"])
                    if event_type == "RESET":
                        for p in game.players: p.rect.topleft = (150, HEIGHT//2)
                        game.add_popup(game.players[0], "THE BIG RESET!", GOLD)
                    elif event_type == "WIND":
                        game.wind_active = True
                        pygame.time.set_timer(pygame.USEREVENT + 2, 5000)
                    elif event_type == "BLACKOUT":
                        game.blackout = True
                        pygame.time.set_timer(pygame.USEREVENT + 3, 4000)
                        
                for event in events:
                    if event.type == pygame.USEREVENT + 2: game.wind_active = False
                    if event.type == pygame.USEREVENT + 3: game.blackout = False
                
                for p in game.players:
                    p.update(keys, events, game)
                    if p.rect.colliderect(game.bot.rect):
                        game.apply_gamble(p)
                        game.bot.rect.x += random.choice([-200, 200])
                        game.bot.rect.y += random.choice([-200, 200])
                        game.bot.rect.clamp_ip(game.track_outer)
                        
                game.bot.update(game.players)
                for popup in game.popups[:]:
                    popup.update()
                    if popup.life <= 0: game.popups.remove(popup)

            # --- RENDER RACE MAIN LAYER ---
            race_surf = pygame.Surface((WIDTH, HEIGHT))
            race_surf.fill((10, 10, 12))
            
            # Dynamic Synthwave Grid Background
            draw_3d_grid(race_surf, (20, 0, 40), 0, ticks)
            
            if game.wind_active:
                for _ in range(10):
                    pygame.draw.line(race_surf, (150,150,150), (random.randint(0, WIDTH), random.randint(0, HEIGHT)), (random.randint(0, WIDTH)+100, random.randint(0, HEIGHT)), 2)
            
            if not game.blackout:
                draw_neon_rect(race_surf, NEON_CYAN, game.track_outer, width=8) # Thicker for pure software blooming
                draw_neon_rect(race_surf, NEON_PINK, game.track_inner, width=8)
                
            for p in game.players:
                for part in p.particles: part.draw(race_surf)
                race_surf.blit(p.image, p.rect)
                
            if not game.blackout: race_surf.blit(game.bot.image, game.bot.rect)
            
            # SCREEN SHAKE LOGIC
            max_shake = max([p.screen_shake_frames for p in game.players] + [0])
            sx, sy = 0, 0
            if max_shake > 0:
                sx = random.randint(-max_shake, max_shake)
                sy = random.randint(-max_shake, max_shake)

            # CHROMATIC ABERRATION LOGIC (Software simulation)
            # If "Chưa Tay Đâu" is active on any player, we split the RGB channels (simulated via BLEND mode)
            needs_aberration = any(p.debuff_active == "Chưa Tay Đâu" for p in game.players)
            
            if needs_aberration and not game.is_paused:
                # To simulate purely in Pygame without shaders:
                # We blit the surface thrice slightly offset using alpha.
                # Since Pygame CE supports blend modes well.
                surf_r = race_surf.copy()
                surf_g = race_surf.copy()
                surf_b = race_surf.copy()
                
                surf_r.fill((255, 0, 0), special_flags=pygame.BLEND_RGBA_MULT)
                surf_g.fill((0, 255, 0), special_flags=pygame.BLEND_RGBA_MULT)
                surf_b.fill((0, 0, 255), special_flags=pygame.BLEND_RGBA_MULT)
                
                offset_val = 8
                screen.fill((0,0,0))
                screen.blit(surf_r, (sx - offset_val, sy), special_flags=pygame.BLEND_ADD)
                screen.blit(surf_g, (sx, sy), special_flags=pygame.BLEND_ADD)
                screen.blit(surf_b, (sx + offset_val, sy), special_flags=pygame.BLEND_ADD)
            else:
                screen.blit(race_surf, (sx, sy))
                
            # DÂN TRÍ ⬇️ EFFECT (Flip Screen for Thread)
            if any(p.name.lower() == "thread" for p in game.players):
                 flipped = pygame.transform.flip(screen, False, True)
                 screen.blit(flipped, (0,0))
            
            # UI layer
            if game.blackout: draw_text_centered(screen, "MẤT ĐIỆN!", game.large_font, WHITE, HEIGHT//2)
            draw_text_centered(screen, f"TIME: {game.time_left}", game.large_font, NEON_CYAN, 10)
            
            leader_y = 10
            screen.blit(game.font.render("Leaderboard", True, GOLD), (10, leader_y)); leader_y += 35
            for i, p in enumerate(sorted(game.players, key=lambda x: x.score, reverse=True)):
                screen.blit(game.small_font.render(f"{i+1}. {p.name} ({p.score}pts)", True, WHITE), (10, leader_y)); leader_y += 25
                
            for popup in game.popups:
                txt = game.popup_font.render(popup.text, True, popup.color)
                # Scaling effect for popups
                if popup.scale != 1.0:
                    txt = pygame.transform.scale(txt, (int(txt.get_width() * popup.scale), int(txt.get_height() * popup.scale)))
                screen.blit(game.font.render(popup.text, True, BLACK), (popup.x - txt.get_width()//2 + 2, popup.y + 2))
                screen.blit(txt, (popup.x - txt.get_width()//2, popup.y))
                
            # Render CRT Overlay on top of EVERYTHING
            screen.blit(CRT_OVERLAY, (0,0))
                
            if game.is_paused:
                overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 200)) # Darker for UI clarity
                screen.blit(overlay, (0, 0))
                draw_text_centered(screen, "Dân Trí ⬇️... System Paused", game.title_font, NEON_RED, HEIGHT//2 - 60)
                draw_text_centered(screen, "Press P to Resume | Q to Quit", game.font, WHITE, HEIGHT//2 + 40)
                
        # --- SUMMARY SCREEN ---
        elif game.state == "SUMMARY":
            screen.fill((20, 15, 20))
            draw_3d_grid(screen, (40, 0, 0), ticks*2, ticks)
            draw_text_centered(screen, "RACE FINISHED", game.title_font, GOLD, 80)
            
            winner = max(game.players, key=lambda x: x.score) if game.players else None
            if winner:
                t = "Wibu Lord" if "wibu" in winner.name.lower() else "Pro Driver"
                if winner.score <= 0: t = "Thánh Ăn Hại"
                draw_text_centered(screen, f"Winner: {winner.name} ({t}!)", game.large_font, NEON_CYAN, 200)
                draw_text_centered(screen, f"Final Score: {winner.score}", game.large_font, GOLD, 280)
                
            draw_text_centered(screen, "Press Q to return to LOBBY", game.font, WHITE, 450)
            screen.blit(CRT_OVERLAY, (0,0))

        pygame.display.flip()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())
