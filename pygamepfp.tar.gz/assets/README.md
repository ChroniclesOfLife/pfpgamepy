# PyGamePFP Racing Project

This is a standalone PyGame project that reuses components from the
`pi5servo360PiAiCamera2Lines` repository to create a simple 2‑player /
bot racing game on a closed track.  The design goals are:

* **Multiplayer:** two human players may control cars with `WASD` and
  arrow keys respectively.
* **Bots:** AI opponents driven by the same PD controller used in the
  original Pi‑5 line follower; `robot_logic.py` is imported from the
  sibling folder (or can be copied into this project).
* **Track:** simple rectangular loop but extensible via `track.py`.
* **Web deployment (GitHub Pages):** the game is compatible with
  `pygbag`/`pygame-web` so it can be compiled and hosted on Pages; see
  the **Deployment** section below.

---

## Requirements

```txt
pygame
# optional: if you want to import RobotLogic directly
-e ../pi5servo360PiAiCamera2Lines
```

Install with pip:

```bash
python -m pip install -r requirements.txt
```

## Running locally

```bash
python main.py
```

Controls:
* **Player 1:** WASD (W=forward, S=back, A=left, D=right)
* **Player 2:** Arrow keys

Bots will automatically follow the black line drawn on the track.

## Deployment via GitHub Pages

1. Install [pygbag](https://github.com/illume/pygbag):
   ```bash
   python -m pip install pygbag
   ```
2. From the project root run:
   ```bash
   python -m pygbag main.py --output gh-pages
   ```
   This generates a static `index.html` and supporting files under
   `gh-pages/` which can be pushed to a repository's `gh-pages` branch.
3. Enable GitHub Pages in your repository settings pointing to the
   `gh-pages` branch or `/docs` folder.

> ⚠️ The game uses only standard PyGame APIs; `pygbag`/`pygame-web` can
> compile it to WebAssembly so it runs in the browser.  No special
> changes are required beyond the scaffold above.

---

Feel free to expand the track, add power‑ups, or adapt the physics to
match your Pi‑servo hardware.